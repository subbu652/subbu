from django.urls import path
from . import views


urlpatterns = [
    path('wish/<str:papa>/<str:son>/', views.wish, name='wish'),
    path('thop/', views.thop, name='thop'),
    path('register/', views.register, name='register'),
    path('display/', views.display,name="display"),
    path('', views.display,name="display"),
    path('remove/<int:id>', views.remove, name='remove'),
    path('edit/<int:id>', views.edit, name='edit'),
    path('login/', views.signup, name='signup'),
    path('signin/', views.signin, name='signin'),
    path('signout/', views.signout, name='signout'),
]
