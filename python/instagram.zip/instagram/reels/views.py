from django.shortcuts import render, redirect
from.models import Student
from django.contrib import messages


# Create your views here.
def register(request):
    if request.method == "POST":
        name = request.POST.get('name')
        age = request.POST.get('age')
        course = request.POST.get('course')
        mobile = request.POST.get('mobile')
        email = request.POST.get('email')
        Student.objects.create(name=name,age=age,course=course,mobile=mobile,email=email)
        messages.info(request, "Record Added Successfully")
    return render(request, "register.html")
from django.contrib.auth .decorators import login_required
@login_required(login_url="signin")
def display(request):
    if request.method == "POST":
        key = request.POST.get('key')
        students=Student.objects.filter(name=key)
        if not students and key.isdigit():
            students=Student.objects.filter(age=int(key))
        if not students and key.isdigit():
            students=Student.objects.filter(mobile=int(key))
        if not students:
            students=Student.objects.filter(email=key)
        if not students:
            students=Student.objects.filter(course=key)
        context = {"students": students}
        return render(request, "tables.html",context)
    data = Student.objects.all()
    context ={"students": data}
    return render(request, "tables.html",context)

def remove(request, id):
    Student.objects.filter(id=id).delete()
    messages.info(request, "Record Deleted")
    return redirect('display')


def edit(request, id):
    # Write your code here
    record = Student.objects.filter(id = id)    # object
    if request.method == "POST":
        name = request.POST.get('name')
        age = request.POST.get('age')
        course = request.POST.get('course')
        mobile = request.POST.get('mobile')
        email = request.POST.get('email')
        record.update(name=name,age=age,course=course,mobile=mobile,email=email)
        messages.info(request, "Record Updated")
        return redirect('display')

    return render(request, "register.html", {'record' : record[0]})


def wish(request, papa, son):
    context = {'papa': papa, 'son': son}
    return render(request, "rhyme.html", context)


def thop(request):
    return render(request,"rebel.html")
# def display1(request):
#     if request.method == "POST":
#         key = request.POST.get('key')
#         students = Student.objects.filter(name=key) or \
#                   (key.isdigit() and Student.objects.filter(age=int(key))) or \
#                   (key.isdigit() and Student.objects.filter(mobile=int(key))) or \
#                   Student.objects.filter(email=key) or \
#                   Student.objects.filter(course=key)
#         context = {"students": students}
#     else:
#         students = Student.objects.all()
#         context = {"students": students}

#     return render(request, "tables.html", context)
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login,logout
def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        fristname=request.POST.get('fristname')
        lastname=request.POST.get('lastname')
        age = request.POST.get('age')
        mobile = request.POST.get('mobile')
        course = request.POST.get('course')
        confirmpassword=request.POST.get('confirmpassword')
        if password ==  confirmpassword:
            user=User.objects.create_user(username=username,password=password,
            email=email,first_name=fristname,last_name=lastname)
            Student.objects.create(age=age,mobile=mobile,course=course,uid=user)
    return render(request, "signup.html")
def signin(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('display')
        else:
            messages.info(request, "Invalid Credentials")
    return render(request, "signin.html")
def signout(request):
    logout(request)
    return redirect('signin')

