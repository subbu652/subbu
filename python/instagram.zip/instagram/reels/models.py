from django.db import models
from django.contrib.auth.models import User
class Student(models.Model):
    age = models.IntegerField()
    mobile = models.CharField(max_length=15)
    course = models.CharField(max_length=100, default="python")
    
    