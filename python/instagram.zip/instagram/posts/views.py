from django.shortcuts import render
from.models import Series
# Create your views here.
def media(request):
    if request.method == "POST":
        name = request.POST.get('name')
        image = request.FILES.get('image')
        video = request.FILES.get('video')
        Series.objects.create(name=name,image=image,video=video)
    return render(request, "media.html")
def display(request):
    data = Series.objects.all()
    context ={"series": data}
    return render(request, "seriesdisplay.html",context)
        
   