from django.db import models

# Create your models here.
class Series(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to="media/images")
    video = models.FileField(upload_to="media/videos")